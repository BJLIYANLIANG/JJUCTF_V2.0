<html>
 <head>
  <title>Lola's website1.0</title>
 </head>
 <body>
 <?php echo '<h1>welcome to my website</h1>'; ?>
 <?php echo '<p>i will never forget to backup my website......</p>'; ?>
 <?php echo '<img src="img/lola.gif" alt="welcome~"/>'; ?>
 </body>
</html>
<?php
$key1 = $_POST['a'];
$key2 = base64_decode('c3ljbDB2ZXI=');
if($key1 === $key2)
{
    //this is a true flag
echo '<p>SYC{xxxxxxxxxxxxxxxxxx}</p>';
}
?>
